<div align="center">

<img src="./assets/header.svg" width="100%" alt="João Marcelo Garcês — Full-Stack Developer" />

<a href="https://github.com/snoopyjmX">
  <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=500&size=16&duration=2800&pause=900&color=00E5FF&center=true&vCenter=true&width=620&lines=%3E+construindo+interfaces+acess%C3%ADveis+e+r%C3%A1pidas;%3E+React+%2B+TypeScript+no+front%2C+Node.js+no+back;%3E+testes%2C+CI%2FCD+e+deploy+de+verdade;%3E+aberto+a+oportunidades+j%C3%BAnior" alt="typing" />
</a>

<br/>

<a href="https://linkedin.com/in/SEU-USUARIO"><img src="https://img.shields.io/badge/linkedin-0a0e14?style=for-the-badge&logo=linkedin&logoColor=00E5FF" /></a>
<a href="mailto:SEU-EMAIL"><img src="https://img.shields.io/badge/email-0a0e14?style=for-the-badge&logo=gmail&logoColor=00E5FF" /></a>
<a href="https://github.com/snoopyjmX?tab=repositories"><img src="https://img.shields.io/badge/repos-0a0e14?style=for-the-badge&logo=github&logoColor=00E5FF" /></a>

</div>

<img src="./assets/divider.svg" width="100%" />

### `// sobre`

```ts
const joao = {
  base: "Goiânia, GO · Brasil",
  estudo: "Engenharia de Software · UniGOiás",
  agora: "Estagiário de TI",
  foco: { frontend: 0.5, backend: 0.3, ops: 0.2 },
  gosto: ["interfaces bem acabadas", "acessibilidade", "testes que pegam bug de verdade"],
  idiomas: ["pt-BR", "en", "es"],
};
```

<img src="./assets/divider.svg" width="100%" />

### `// projetos`

<sub>clique para expandir ▾</sub>

<details>
<summary><b>◆ Sillage</b> · PWA de catálogo e coleção de perfumaria de nicho · <code>em desenvolvimento</code></summary>
<br/>

<!-- <img src="./assets/sillage-demo.gif" width="100%" /> -->

Enciclopédia e coleção pessoal de perfumes, com busca tolerante a acentos e filtros por notas olfativas.

| área | detalhe |
|---|---|
| stack | React 19 · Vite · TypeScript · Tailwind · TanStack Query · Zod · Supabase |
| qualidade | 49 testes E2E (Playwright) · 220 testes de banco (pgTAP) · axe-core WCAG AA |
| entrega | GitHub Actions com testes de unidade, banco e E2E a cada PR |
| status | fases 1–4 concluídas · próxima: preview por PR e autenticação |

<sub>repositório privado durante o refinamento</sub>

</details>

<details>
<summary><b>◆ NÓS</b> · app para casais · <code>em produção</code></summary>
<br/>

<!-- <img src="./assets/nos-demo.gif" width="100%" /> -->

App mobile-first com mensagens, memórias e contagem de datas, focado em experiência visual e performance.

| área | detalhe |
|---|---|
| stack | React Native · Expo Router · TypeScript · Reanimated · Supabase (Auth, Realtime, Storage) |
| segurança | RLS versionada · convites por código · cabeçalhos de segurança · auditoria de dependências |
| entrega | PWA na Vercel |

[repositório →](https://github.com/snoopyjmX/SEU-REPO-NOS)

</details>

<details>
<summary><b>◆ Paggo.AI</b> · controle financeiro pessoal (TCC, equipe de 3) · <code>em desenvolvimento</code></summary>
<br/>

Plataforma web e mobile de finanças pessoais com integração Open Finance.

| área | detalhe |
|---|---|
| stack | React · React Router · Recharts · Node.js · Express · Prisma · PostgreSQL · Expo |
| meu papel | front-end web (cadastros de usuário, bancos e investimentos) e QA |

[repositório →](https://github.com/SEU-USUARIO/SEU-REPO-PAGGO)

</details>

<img src="./assets/divider.svg" width="100%" />

### `// stack`

<p align="center">
  <img src="https://skillicons.dev/icons?i=react,ts,js,vite,tailwind,html,css&theme=dark" /><br/>
  <img src="https://skillicons.dev/icons?i=nodejs,express,postgres,prisma,supabase&theme=dark" /><br/>
  <img src="https://skillicons.dev/icons?i=docker,githubactions,vercel,git,vscode&theme=dark" />
</p>

<img src="./assets/divider.svg" width="100%" />

### `// atividade`

<p align="center">
  <img width="100%" src="https://github-readme-activity-graph.vercel.app/graph?username=snoopyjmX&bg_color=0a0e14&color=8b949e&line=00e5ff&point=7c5cff&area=true&area_color=00e5ff&hide_border=true&radius=10&custom_title=commits%20nos%20%C3%BAltimos%2031%20dias" alt="gráfico de atividade" />
</p>

<p align="center">
  <img width="49%" src="https://github-readme-stats.vercel.app/api?username=snoopyjmX&show_icons=true&include_all_commits=true&count_private=true&hide_border=true&bg_color=0a0e14&title_color=00e5ff&icon_color=00e5ff&text_color=c9d1d9&ring_color=7c5cff&border_radius=10" alt="stats" />
  <img width="49%" src="https://streak-stats.demolab.com/?user=snoopyjmX&hide_border=true&background=0a0e14&ring=00e5ff&fire=7c5cff&currStreakLabel=00e5ff&sideLabels=8b949e&dates=6e7681&stroke=30363d&border_radius=10&locale=pt_BR" alt="streak" />
</p>

<details>
<summary><b>▸ métricas detalhadas</b> · calendário, linguagens, horários de commit, repositórios</summary>
<br/>
<p align="center">
  <img width="100%" src="https://raw.githubusercontent.com/snoopyjmX/snoopyjmX/main/metrics.svg" alt="métricas" />
</p>
</details>

<br/>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/snoopyjmX/snoopyjmX/output/github-snake-dark.svg" />
    <img width="100%" alt="contribuições" src="https://raw.githubusercontent.com/snoopyjmX/snoopyjmX/output/github-snake.svg" />
  </picture>
</p>

<img src="./assets/divider.svg" width="100%" />

<div align="center">
<sub><code>$ git commit -m "sempre aprendendo"</code></sub>
</div>
